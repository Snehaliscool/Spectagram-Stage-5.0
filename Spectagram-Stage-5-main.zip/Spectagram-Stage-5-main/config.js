export const firebaseConfig = {
  apiKey: "AIzaSyBi0T_Vw__wjxEyjt-EW0wecMH1FYIzyoE",
  authDomain: "spectagram-app-fe7e7.firebaseapp.com",
  projectId: "spectagram-app-fe7e7",
  storageBucket: "spectagram-app-fe7e7.appspot.com",
  messagingSenderId: "381765449869",
  appId: "1:381765449869:web:d8fbae108c07a36e4a0ac4"
};